
/*import { createClient } from '@supabase/supabase-js';

export const supabaseUrl = 'https://dhgosezlpedgltzolpqm.supabase.co' ;
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRoZ29zZXpscGVkZ2x0em9scHFtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTY4MjY1NzksImV4cCI6MjAzMjQwMjU3OX0.RDqlwJpKsus48BN4YbaK-iLhxeXBEZGTUuk3N0Ol5EE" ;
const supabase = createClient(supabaseUrl, supabaseKey) ;

export default supabase; */



import { createClient } from '@supabase/supabase-js'
export const supabaseUrl = 'https://zuoszsiohfqllarpqwxm.supabase.co'
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp1b3N6c2lvaGZxbGxhcnBxd3htIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MTc0MjQxMTIsImV4cCI6MjAzMzAwMDExMn0.Z5tF1Ur7FCOrt5S391YpH4VReNEHa_FMxbHQ_8hJ6vc"
const supabase = createClient(supabaseUrl, supabaseKey);

export default supabase;